ln -s ../Prueba1/cir1.sp .
ln -s ../Prueba1/cir2.sp .
ln -s ../Pruena1/MOSIS_018umparam.lib .
