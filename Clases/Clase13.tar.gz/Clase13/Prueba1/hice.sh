ngspice -b -o cir1.lis cir1.sp
ngspice -b -o cir2.lis cir2.sp
