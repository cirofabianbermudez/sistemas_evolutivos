# Esta es una función
# en python

def f( x ) :
	v = (x-2)*(x-3)
	return v

