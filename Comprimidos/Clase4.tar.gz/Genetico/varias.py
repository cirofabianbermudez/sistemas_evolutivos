from subprocess import call

n = 30
i = 0
while i< n:
	call(["python", "corre.py"])
	i += 1 
