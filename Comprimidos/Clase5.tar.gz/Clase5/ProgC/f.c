double f( double x )
{
	return x*x;
}
