import numpy as np

X = np.genfromtxt( "datos.txt" )
print( X.shape )

print( X )
